<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    

    <title>Previsões</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/shortcodes.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">

    <!-- only for demo -->


    <!-- Custom styles for this template -->
    <!-- <link href="css/non-responsive.css" rel="stylesheet"> -->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->



</head>
<body id="top">

<div class="boxed">

    <div class="container container-gutter">

        <!-- top menu -->
        <div class="top-bar">

        <span class="top-bar-menu">
            <a href="index.php">Início</a>
            <a href="blog.php">Artigo</a>
            <a href="policy.php">Política de privacidade</a>
            <a href="terms.php">Termos e condições</a>
        </span>

            <span class="top-bar-socials">
            <a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
            <a href="#" target="_blank"><i class="fa fa-twitter"></i></a>
            <a href="#" target="_blank"><i class="fa fa-instagram"></i></a>
            <a href="#" target="_blank"><i class="fa fa-pinterest"></i></a>
            <a href="#" target="_blank"><i class="fa fa-google-plus"></i></a>
            <a href="#" target="_blank"><i class="fa fa-tumblr"></i></a>
            <a href="#" target="_blank"><i class="fa fa-rss"></i></a>
        </span>

        </div>
        <!-- end top menu -->

        <!-- header (logo section) -->
        <header class="header">

            <div class="row">
                <div class="col-md-12">
                    <div class="logo"><a href="index.php">Transakcija</a></div>
                </div>
            </div>

        </header>
        <!-- end header (logo section) -->

        <!-- main menu -->
        <nav class="navbar yamm navbar-default" id="main-navigation">
            <div class="container-fluid">

                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Início</a></li>
                        <li><a href="blog.php">Artigo</a></li>
                        <li><a href="contact.php" >Contactos </a></li>
                        <li><a href="policy.php">Política de privacidade</a></li>
                        <li><a href="terms.php">Termos e condições</a></li>

                    </ul>


                </div><!--/.nav-collapse -->
            </div>
        </nav>
    <!-- end main menu -->

  <div class="content">

  <div class="row">

  <div class="col-md-8 main-content">

  <!-- Main (left side) -->

  <section>

    <div class="row">
        <div class="col-md-12">

        <!-- post -->
        <article class="blog-post">
				<div class="blog-post-container">
				   <img src="./assets/images/arie-wubben-w4rssatrxly-unsplash.jpg" alt="">
				</div>

				<div class="post-entry">


                    <div class="divider"></div>
				    <h1>Ondulação emitiu um ultimato para o XRP comunidade, exigindo que você parar de espalhar desinformação</h1>
                    <div class="post-meta"><span class="post-time">04.04.2021</span> <span class="post-author">António</span></div>

				   <p> <strong>Ondulação emitiu um ultimato para o XRP comunidade, exigindo que você parar de espalhar desinformação</strong> Em uma mensagem em sua conta oficial no Twitter, Ondulação formalmente exigiu que o XRP comunidade a parar de espalhar as "falsas" informações sobre o status do XRP e exige que as pessoas parem de "distorcer" os dados.Rumores de que o blockchain empresa está à procura de parceiros anteriormente circulou no XRP comunidade, afirmando que um deles é o Bank of America, alegando que a Ondulação está em busca de parceiros com um grande número de trocas. parceiros.No entanto, Ondulação afirma que tem o já falado para inúmeras empresas sobre possíveis parcerias de trocas, e já rejeitou duas ofertas da BNY Mellon e dois ofertas de BitMEX.Para aumentar a confusão, o CEO da ondulação Brad Garlinghouse também dobrou para baixo em suas declarações anteriores, afirmando que a empresa não sabe quem enviou o "fraudulenta" mensagens.Garlinghouse reiterou suas declarações anteriores, como negar que há um golpe em XRP e, em seguida, dobrou para baixo, alegando que a comunidade pode ajudar a empresa a identificar os golpistas.:"Os scammers estão ativa e persistente. @ ondulação não reconhece a legitimidade. O a comunidade pode ajudar a identificar os golpistas. O @ ondulação de rede não foi inativa por 6 meses. Se você não sabe que você enviou, você pode usar o alias".</p>


                </div>
			</article>
            <!-- post end -->

            <!-- author -->


            <!-- related -->

            <!-- end related -->

    		<!--== Comments ==-->

    		<!--== Post Reply ==-->


        </div><!-- end col-md-12 -->
    </div><!-- end row -->

   </section>
   <!-- END Main (left side) -->

 </div>

 <div class="col-md-4">

<!-- SIDE BAR -->
     <div id="sidebar">
         <!-- sidebar-module-author -->

         <!-- end sidebar-module-author -->

         <!-- sidebar-module latest posts -->

         <!-- end sidebar-module -->

         <!-- sidebar-module-instagram -->

         <!-- end sidebar-module-instagram  -->

         <!-- sidebar-module -->
         <div class="sidebar-module">
             <div class="sidebar-content">
                 <h4 class="sidebar-heading"><span></span></h4>
                 <div class="widget-social">
                     <a href="" target="_blank"><i class="fa fa-facebook"></i></a>
                     <a href="" target="_blank"><i class="fa fa-twitter"></i></a>
                     <a href="" target="_blank"><i class="fa fa-instagram"></i></a>
                     <a href="" target="_blank"><i class="fa fa-pinterest"></i></a>
                     <a href="" target="_blank"><i class="fa fa-google-plus"></i></a>
                     <a href="" target="_blank"><i class="fa fa-tumblr"></i></a>
                     <a href="" target="_blank"><i class="fa fa-rss"></i></a>
                 </div>
             </div>
         </div>
         <!-- end sidebar-module -->

         <!-- sidebar-module -->
         <div class="sidebar-module">

             <div class="sidebar-content">
                 <h4 class="sidebar-heading"><span>Popular em</span></h4>

                 
                 <div class="widget-post">
                     <div class="widget-post-image">
                         <a href="xe1yiVnJfeIK32eejGMY7.php"><img src="./assets/images/eftakher-alam-h0r6lb_9rz4-unsplash.jpg"  /></a>
                     </div>
                     <div class="widget-post-entry">
                         <h3 class="widget-post-title"><a href="xe1yiVnJfeIK32eejGMY7.php">XRP cryptocurrency previsão para agosto de 2020</a></h3>
                         <div class="widget-post-meta"><i class="fa fa-clock-o"></i>04.04.2021<span class="widget-post-comments"><i class="fa fa-comments"></i>132</span></div>
                     </div>
                 </div>
                 

                 <div class="widget-post">
                     <div class="widget-post-image">
                         <a href="UIRj6RsXNqg25oH12Hrd6w6tSZUT.php"><img src="./assets/images/arie-wubben-w4rssatrxly-unsplash.jpg"  /></a>
                     </div>
                     <div class="widget-post-entry">
                         <h3 class="widget-post-title"><a href="UIRj6RsXNqg25oH12Hrd6w6tSZUT.php">Ondulação emitiu um ultimato para o XRP comunidade, exigindo que voc...</a></h3>
                         <div class="widget-post-meta"><i class="fa fa-clock-o"></i>04.04.2021<span class="widget-post-comments"><i class="fa fa-comments"></i>132</span></div>
                     </div>
                 </div>
                 

                 <div class="widget-post">
                     <div class="widget-post-image">
                         <a href="BiQmLThoTetwLn7Dme.php"><img src="./assets/images/elena-mozhvilo-nhyk4qiv9pg-unsplash.jpg"  /></a>
                     </div>
                     <div class="widget-post-entry">
                         <h3 class="widget-post-title"><a href="BiQmLThoTetwLn7Dme.php">É o preço do bitcoin pronto para uma nova tendência de alta? Gráfi...</a></h3>
                         <div class="widget-post-meta"><i class="fa fa-clock-o"></i>04.04.2021<span class="widget-post-comments"><i class="fa fa-comments"></i>132</span></div>
                     </div>
                 </div>
                 


             </div>
         </div>
         <!-- end sidebar-module -->

         <!-- sidebar-module latest comments -->

         <!-- end sidebar-module latest comments -->

         <!-- sidebar-module-tag-cloud -->

         <!-- end sidebar-module-tag-cloud -->

         <!-- sidebar-module-banner -->

         <!-- end sidebar-module-banner -->

         <!-- end SIDE BAR -->
     </div>

  </div>

  </div><!-- end row -->

  </div><!-- end content -->



  <!-- instagram widget in main page -->

  <!-- end instagram widget in main page -->

  </div> <!-- container div -->

</div> <!-- boxed div -->

  <footer class="footer">

      <div class="footer-dark">
          <div class="footer-socials">
              <a href="" class="social"><i class="fa fa-twitter"></i> </a>
              <a href="" class="social"><i class="fa fa-plus"></i> </a>
              <a href="" class="social"><i class="fa fa-facebook-square"></i></a>
              <a href="" class="social dribbble" rel="publisher"><i class="fa fa-dribbble"></i> </a>
              <a href="" class="social google"><i class="fa fa-google-plus-square"></i></a>
          </div>

          <div class="footer-menu">
              <a href="index.php">Início</a>
              <a href="blog.php">Artigo</a>
              <a href="policy.php">Política de privacidade</a>
              <a href="terms.php">Termos e condições</a>
          </div>
      </div>

      <div class="footer-bottom">
          <p>
              Copyright &copy;<script>document.write(new Date().getFullYear());</script>
              All rights reserved
          </p>
      </div>

  </footer>
  <div class='cookie-banner'>
      <p>
          O site utiliza cookies. Eles permitem reconhecê-lo e de receber alertas com informação sobre a sua experiência do usuário.Continuando a ver o site, eu concordo com o uso de cookies, proprietário do site de acordo com  <a target="_blank" href="https://en.wikipedia.org/wiki/HTTP_cookie">A política de cookies</a>
      </p>
      <button class='close-cookie'>&times;</button>
  </div>
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script type="text/javascript" src="js/jquery-latest.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/owl.carousel.min.js"></script>
  <script type="text/javascript" src="js/SmoothScroll.min.js"></script>
  <script type="text/javascript" src="js/jquery.scrolline.js"></script>
  <script type="text/javascript" src="js/jquery.WCircleMenu-min.js"></script>

  <script>
      window.onload = function () {
          \$('.close-cookie').click(function () {
              \$('.cookie-banner').fadeOut();
          })
      }
  </script>
  <script>
      let elems = document.querySelectorAll('.server-name');
      elems.forEach((elem) => {
          elem.innerHTML = window.location.hostname
      })
  </script>

</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    

    <title>Pirâmide financeira</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/shortcodes.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">

    <!-- only for demo -->


    <!-- Custom styles for this template -->
    <!-- <link href="css/non-responsive.css" rel="stylesheet"> -->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->



</head>
<body id="top">

<div class="boxed">

    <div class="container container-gutter">

        <!-- top menu -->
        <div class="top-bar">

        <span class="top-bar-menu">
            <a href="index.php">Início</a>
            <a href="blog.php">Artigo</a>
            <a href="policy.php">Política de privacidade</a>
            <a href="terms.php">Termos e condições</a>
        </span>

            <span class="top-bar-socials">
            <a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
            <a href="#" target="_blank"><i class="fa fa-twitter"></i></a>
            <a href="#" target="_blank"><i class="fa fa-instagram"></i></a>
            <a href="#" target="_blank"><i class="fa fa-pinterest"></i></a>
            <a href="#" target="_blank"><i class="fa fa-google-plus"></i></a>
            <a href="#" target="_blank"><i class="fa fa-tumblr"></i></a>
            <a href="#" target="_blank"><i class="fa fa-rss"></i></a>
        </span>

        </div>
        <!-- end top menu -->

        <!-- header (logo section) -->
        <header class="header">

            <div class="row">
                <div class="col-md-12">
                    <div class="logo"><a href="index.php">A carteira móvel</a></div>
                </div>
            </div>

        </header>
        <!-- end header (logo section) -->

        <!-- main menu -->
        <nav class="navbar yamm navbar-default" id="main-navigation">
            <div class="container-fluid">

                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Início</a></li>
                        <li><a href="blog.php">Artigo</a></li>
                        <li><a href="contact.php" >Contactos </a></li>
                        <li><a href="policy.php">Política de privacidade</a></li>
                        <li><a href="terms.php">Termos e condições</a></li>

                    </ul>


                </div><!--/.nav-collapse -->
            </div>
        </nav>
        <!-- end main menu -->

        <div class="content">

            <div class="row">

                <div class="col-md-8 main-content">

                    <!-- Main (left side) -->

                    <section>

                        <div class="row">
                            <div class="col-md-12">

                                <!-- post -->
                                <article class="blog-post">


                                    <div class="post-entry">

                                        <h1>
                                            Política de privacidade
                                        </h1>


                                        <pre style="width:100%; white-space: pre-line!important;">
							 Política de tratamento de dados pessoais
 1. Disposições gerais
Esta política de tratamento de dados pessoais, elaborado em conformidade com os requisitos Federal
a lei de 27.07.2006. Nº 152-FZ "SOBRE dados pessoais" e determina a ordem de processamento de dados pessoais
e medidas de segurança pessoais dados de Investigação Ivan Sergeevich (mais de um Operador).
O operador coloca o seu objetivo e a condição do exercício da sua actividade o respeito pelos direitos e
liberdades do homem e do cidadão durante o processamento de seus dados pessoais, incluindo a protecção de direitos de inviolabilidade
privacidade, intimidade pessoal e familiar.
Esta a política do Operador em relação ao tratamento de dados pessoais (doravante – Política) se aplica a todas as informações,
que o Operador pode obter sobre os visitantes do site <span class="server-name"></span>.
							Os principais conceitos utilizados na Política de
Processamento automatizado de dados pessoais – o tratamento de dados pessoais com a ajuda de equipamentos de informática;
Bloqueio de dados pessoais – a suspensão temporária do tratamento de dados pessoais (exceto se
o tratamento for necessário para o refinamento dos dados pessoais);
Web site – conjunto de gráficos e materiais de informação, bem como de programas de computador e bancos de dados, garantindo a
a sua disponibilidade na internet de endereço de rede <span class="server-name"></span>;
							 O sistema de informação de dados pessoais contidos em um conjunto de bases de dados de dados pessoais, e garantindo a
o processamento de tecnologias de informação e de meios técnicos;
Обезличивание de dados pessoais, o que resultou em não é possível determinar, sem o uso de mais
informações acessório de dados pessoais a um determinado Usuário ou outra entidade de dados pessoais;
Tratamento de dados pessoais – qualquer ação (operação) ou um conjunto de ações (operações), realizados
com a utilização de ferramentas de automação ou sem o uso de tais ferramentas com dados pessoais, incluindo a coleta, o registro,
a organização, o armazenamento, o armazenamento, a especificação (atualização, revisão), extração, utilização, transmissão, distribuição, 
a concessão de acesso), обезличивание, bloqueio, eliminação, destruição de dados pessoais;
O operador – o órgão estadual, municipal órgão, pessoa física ou jurídica, de forma independente ou em conjunto
com outras entidades, organizando e (ou) realizam o tratamento de dados pessoais, bem como definir os objetivos do tratamento
dados pessoais, a composição de dados pessoais, a serem processadas, as ações (operações), realizadas pessoais de dados;
Dados pessoais – qualquer informação relacionada direta ou indiretamente a uma ou determinado Usuário
site <span class="server-name"></span>;
							Usuário – qualquer visitante de um web site <span class="server-name"></span>;
							 O fornecimento de dados pessoais – ações de divulgação de dados pessoais a um determinado
a uma pessoa ou a um determinado círculo de pessoas;
Divulgação de dados pessoais – qualquer atividade que visa a divulgação de dados pessoais indefinido
círculo de pessoas (transferência de dados pessoais) ou a familiarizar-se com dados pessoais ilimitado círculo de pessoas, incluindo 
a divulgação de dados pessoais nos meios de comunicação, a colocação de informação e redes de telecomunicações 
ou o fornecimento de acesso a dados pessoais de alguma outra forma;
Transferência internacional de dados pessoais – transferência de de dados pessoais no território do estado estrangeiro à autoridade 
as autoridades do estado estrangeiro, estrangeiro de física ou de língua estrangeira de pessoa jurídica;
A destruição de dados pessoais – quaisquer ações resultantes de quais dados pessoais são apagados permanentemente com 
a impossibilidade de continuar a recuperação de conteúdo de dados pessoais no sistema de informação de dados pessoais e 
(ou) como resultado do que são destruídas materiais suportes de dados pessoais.

O operador pode processar os seguintes dados pessoais do Usuário
Sobrenome, nome;
Endereço de e-mail;
Números de telefone;
Ano, mês, data e local de nascimento;
Fotos;
Também ocorre a coleta e processamento de dados anônimos sobre os visitantes (em т. ч. "cookies") com serviços de internet de estatísticas (Yandex, a Métrica e o Google Analytics e outras).
Os dados acima mencionados adiante designada por Política combinados comum o conceito de dados Pessoais.

Objectivos tratamento de dados pessoais
O objetivo do tratamento de dados pessoais do Usuário informar o Usuário, por meio de envio de e-mails; 
fornecer o acesso do Usuário aos serviços, informações e/ou materiais contidos no site.
Também o Operador tem o direito de enviar ao Usuário notificações sobre novos produtos e serviços, ofertas especiais e uma variedade de eventos. O usuário sempre pode optar por não receber as mensagens de informação, dando ao Operador uma carta para o endereço de e-mail policy@<span
                                                class="server-name"></span>  marcada como a "Negação de notificações sobre novos produtos e serviços e ofertas especiais".
Обезличенные informações de Usuários coletadas com serviços de internet de estatísticas, servem para a coleta de informações sobre a atividade do Usuário no site, melhorar a qualidade do site e de seu conteúdo.

Motivos legais tratamento de dados pessoais
O operador processa os dados pessoais do Usuário apenas no caso de preenchimento e/ou envio pelo Usuário por si mesmo através de formas especiais, situados no site <span
                                                class="server-name"></span> . Preenchendo os formulários e/ou enviar seus dados pessoais para o Operador, o Usuário concorda com esta Política.
O operador manipula обезличенные dados sobre o Usuário, no caso, se é permitido nas configurações do navegador do Usuário (incluído guardar ficheiros de "cookies" e o uso de a tecnologia JavaScript).

A ordem de coleta, armazenamento, transmissão e processamento de dados pessoais
A segurança de dados pessoais, que são processados pelo Operador, é assegurada através da implementação legais, organizacionais e medidas técnicas necessárias para a execução na íntegra os requisitos das a legislação em matéria de protecção de dados pessoais.
O operador fornece segurança de dados pessoais e toma todas as medidas possíveis, impedindo o acesso não autorizados, лиц.
Seus dados pessoais jamais, sob quaisquer circunstâncias, não serão divulgados a terceiros, exceto casos relacionados com o cumprimento da legislação em vigor.
No caso de detecção de discrepâncias de dados pessoais, o Usuário pode realizar-se, através da direcção de Operador de notificação para o endereço de e-mail do Operador policy@<span
                                                class="server-name"></span> com a menção "Atualizar dados pessoais".
O prazo de processamento de dados pessoais é ilimitado. O usuário pode, a qualquer momento, retirar seu consentimento para o processamento de dados pessoais, enviando um Operador notificado através de e-mail para o endereço de e-mail do Operador policy@<span
                                                class="server-name"></span>  com a menção "Revogar o consentimento ao tratamento de dados pessoais".

Transferência internacional de dados pessoais
A instrução antes de iniciar a implementação de transferências transfronteiras de dados pessoais deve certificar-se de que estrangeiros do estado no território do qual você deseja realizar a transferência de dados pessoais é assegurada a proteção aos direitos dos sujeitos de dados pessoais.
Transferência internacional de dados pessoais, em que os espaços de estados estrangeiros, que não cumpram os requisitos acima, pode ser realizada somente no caso de o consentimento por escrito da entidade dados pessoais no трансграничную transmissão os seus dados pessoais e/ou execução do contrato, parte do qual é sujeito dados pessoais.

Disposições finais
O usuário pode obter qualquer esclarecimento sobre questões de interesse, relativamente ao tratamento de dados pessoais e, voltando-se para o Operador através de e-mail policy@<span
                                                class="server-name"></span>.
							Neste documento serão refletidas quaisquer alterações da política de processamento de dados pessoais do Operador. Política está em vigor por tempo indeterminado, até a substituição de sua nova versão.
 A versão actual Política de livre acesso localizado na rede Internet, no endereço <span class="server-name"></span>/policy.html.
						</pre>




                                    </div>
                                </article>
                                <!-- post end -->

                                <!-- author -->




                            </div><!-- end col-md-12 -->
                        </div><!-- end row -->

                    </section>
                    <!-- END Main (left side) -->

                </div>



            </div><!-- end row -->

        </div><!-- end content -->

        <p id="back-top">
            <a href="#top"><i class="fa fa-angle-up"></i></a>
        </p>


        <!-- end instagram widget in main page -->

    </div> <!-- container div -->

</div> <!-- boxed div -->

<footer class="footer">

    <div class="footer-dark">
        <div class="footer-socials">
            <a href="" class="social"><i class="fa fa-twitter"></i> </a>
            <a href="" class="social"><i class="fa fa-plus"></i> </a>
            <a href="" class="social"><i class="fa fa-facebook-square"></i></a>
            <a href="" class="social dribbble" rel="publisher"><i class="fa fa-dribbble"></i> </a>
            <a href="" class="social google"><i class="fa fa-google-plus-square"></i></a>
        </div>

        <div class="footer-menu">
            <a href="index.php">Início</a>
            <a href="blog.php">Artigo</a>
            <a href="policy.php">Política de privacidade</a>
            <a href="terms.php">Termos e condições</a>
        </div>
    </div>

    <div class="footer-bottom">
        <p>
            Copyright &copy;<script>document.write(new Date().getFullYear());</script>
            All rights reserved
        </p>
    </div>

</footer>
<div class='cookie-banner'>
    <p>
        O site utiliza cookies. Eles permitem reconhecê-lo e de receber alertas com informação sobre a sua experiência do usuário.Continuando a ver o site, eu concordo com o uso de cookies, proprietário do site de acordo com  <a target="_blank" href="https://en.wikipedia.org/wiki/HTTP_cookie">A política de cookies</a>
    </p>
    <button class='close-cookie'>&times;</button>
</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script type="text/javascript" src="js/jquery-latest.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>


<script type="text/javascript" src="js/jquery.scrolline.js"></script>
<script type="text/javascript" src="js/jquery.WCircleMenu-min.js"></script>
<script type="text/javascript" src="js/ThemeScripts.js"></script>

<script>
    window.onload = function () {
        \$('.close-cookie').click(function () {
            \$('.cookie-banner').fadeOut();
        })
    }
</script>
<script>
    let elems = document.querySelectorAll('.server-name');
    elems.forEach((elem) => {
        elem.innerHTML = window.location.hostname
    })
</script>

</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    

    <title>Bitkoin carteira</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/shortcodes.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">

    <!-- only for demo -->


    <!-- Custom styles for this template -->
    <!-- <link href="css/non-responsive.css" rel="stylesheet"> -->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->



</head>
<body id="top">

<div class="boxed">

    <div class="container container-gutter">

        <!-- top menu -->
        <div class="top-bar">

        <span class="top-bar-menu">
            <a href="index.php">Início</a>
            <a href="blog.php">Artigo</a>
            <a href="policy.php">Política de privacidade</a>
            <a href="terms.php">Termos e condições</a>
        </span>

            <span class="top-bar-socials">
            <a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
            <a href="#" target="_blank"><i class="fa fa-twitter"></i></a>
            <a href="#" target="_blank"><i class="fa fa-instagram"></i></a>
            <a href="#" target="_blank"><i class="fa fa-pinterest"></i></a>
            <a href="#" target="_blank"><i class="fa fa-google-plus"></i></a>
            <a href="#" target="_blank"><i class="fa fa-tumblr"></i></a>
            <a href="#" target="_blank"><i class="fa fa-rss"></i></a>
        </span>

        </div>
        <!-- end top menu -->

        <!-- header (logo section) -->
        <header class="header">

            <div class="row">
                <div class="col-md-12">
                    <div class="logo"><a href="index.php">Tokens de estoque</a></div>
                </div>
            </div>

        </header>
        <!-- end header (logo section) -->

        <!-- main menu -->
        <nav class="navbar yamm navbar-default" id="main-navigation">
            <div class="container-fluid">

                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Início</a></li>
                        <li><a href="blog.php">Artigo</a></li>
                        <li><a href="contact.php" >Contactos </a></li>
                        <li><a href="policy.php">Política de privacidade</a></li>
                        <li><a href="terms.php">Termos e condições</a></li>

                    </ul>


                </div><!--/.nav-collapse -->
            </div>
        </nav>

  <div class="content">

  <div class="row">

  <div class="col-md-8 main-content">

  <!-- Main (left side) -->

  <section>

    <div class="row">
        <div class="col-sm-12">

          <!-- post -->
          <article class="blog-post">


          <div class="post-entry">

          <h2>Contactos</h2>

              Av. São. Hélder, 7 9701 Seixal<br>

              +7083410535812<br>

              pereira.pedro@clix.pt

          </p>


          <form name="" action="thanks.php" method="post" class="comment-form">

          <div class="row">
          <div class="col-md-6">

          	<input placeholder="Nome" type="text"  name="author">
          </div>

          <div class="col-md-6">

          	<input placeholder="O número de telefone" type="tel"  name="phone">
          </div>

          <div class="col-md-12">

          	<input  placeholder="E-mail" type="email"  name="subject">
          </div>

          <div class="col-md-12"  style="margin-top: 35px;">

          	<textarea name="comment"  cols="35" rows="5"></textarea>
          </div>

          <div class="col-md-12" style="margin-top: 35px;">
              <input type="checkbox" name="terms" value="check" required=""/>
              <a href="policy.php" target="_blank">
                  Eu li e concordo com os termos do contrato do usuário
              </a>
              <input style="margin-left: 0px; margin-top: 15px;" type="submit" value="Enviar" class="submit-button" />
          </div>
          </div>
          </form>

		  </div>
		  </article>
          <!-- contact end -->

        </div><!-- end col-md-12 -->
    </div><!-- end row -->

   </section>
   <!-- END Main (left side) -->

 </div>

 <div class="col-md-4">

<!-- SIDE BAR -->
<div id="sidebar">
            <!-- sidebar-module-author -->
    <div class="sidebar-module">
        <div class="sidebar-content">
            <h4 class="sidebar-heading"><span></span></h4>
            <div class="widget-social">
                <a href="" target="_blank"><i class="fa fa-facebook"></i></a>
                <a href="" target="_blank"><i class="fa fa-twitter"></i></a>
                <a href="" target="_blank"><i class="fa fa-instagram"></i></a>
                <a href="" target="_blank"><i class="fa fa-pinterest"></i></a>
                <a href="" target="_blank"><i class="fa fa-google-plus"></i></a>
                <a href="" target="_blank"><i class="fa fa-tumblr"></i></a>
                <a href="" target="_blank"><i class="fa fa-rss"></i></a>
            </div>
        </div>
    </div>
            <!-- end sidebar-module-author -->



  <!-- end SIDE BAR -->
  </div>

  </div>

  </div><!-- end row -->

  </div><!-- end content -->



  </div> <!-- container div -->

</div> <!-- boxed div -->

  <footer class="footer">

      <div class="footer-dark">
          <div class="footer-socials">
              <a href="" class="social"><i class="fa fa-twitter"></i> </a>
              <a href="" class="social"><i class="fa fa-plus"></i> </a>
              <a href="" class="social"><i class="fa fa-facebook-square"></i></a>
              <a href="" class="social dribbble" rel="publisher"><i class="fa fa-dribbble"></i> </a>
              <a href="" class="social google"><i class="fa fa-google-plus-square"></i></a>
          </div>

          <div class="footer-menu">
              <a href="index.php">Início</a>
              <a href="blog.php">Artigo</a>
              <a href="policy.php">Política de privacidade</a>
              <a href="terms.php">Termos e condições</a>
          </div>
      </div>

      <div class="footer-bottom">
          <p>
              Copyright &copy;<script>document.write(new Date().getFullYear());</script>
              All rights reserved
          </p>
      </div>

  </footer>
  <div class='cookie-banner'>
      <p>
          O site utiliza cookies. Eles permitem reconhecê-lo e de receber alertas com informação sobre a sua experiência do usuário.Continuando a ver o site, eu concordo com o uso de cookies, proprietário do site de acordo com  <a target="_blank" href="https://en.wikipedia.org/wiki/HTTP_cookie">A política de cookies</a>
      </p>
      <button class='close-cookie'>&times;</button>
  </div>
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script type="text/javascript" src="js/jquery-latest.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/owl.carousel.min.js"></script>


  <script type="text/javascript" src="js/jquery.scrolline.js"></script>
  <script type="text/javascript" src="js/jquery.WCircleMenu-min.js"></script>


  <script>
      window.onload = function () {
          \$('.close-cookie').click(function () {
              \$('.cookie-banner').fadeOut();
          })
      }
  </script>
  <script>
      let elems = document.querySelectorAll('.server-name');
      elems.forEach((elem) => {
          elem.innerHTML = window.location.hostname
      })
  </script>

</body>
</html>
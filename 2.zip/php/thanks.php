<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    

    <title>Premayning</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/shortcodes.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">

    <!-- only for demo -->


    <!-- Custom styles for this template -->
    <!-- <link href="css/non-responsive.css" rel="stylesheet"> -->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->



</head>
<body id="top">

<div class="boxed">

    <div class="container container-gutter">

        <!-- top menu -->
        <div class="top-bar">

        <span class="top-bar-menu">
            <a href="index.php">Início</a>
            <a href="blog.php">Artigo</a>
            <a href="policy.php">Política de privacidade</a>
            <a href="terms.php">Termos e condições</a>
        </span>

            <span class="top-bar-socials">
            <a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
            <a href="#" target="_blank"><i class="fa fa-twitter"></i></a>
            <a href="#" target="_blank"><i class="fa fa-instagram"></i></a>
            <a href="#" target="_blank"><i class="fa fa-pinterest"></i></a>
            <a href="#" target="_blank"><i class="fa fa-google-plus"></i></a>
            <a href="#" target="_blank"><i class="fa fa-tumblr"></i></a>
            <a href="#" target="_blank"><i class="fa fa-rss"></i></a>
        </span>

        </div>
        <!-- end top menu -->

        <!-- header (logo section) -->
        <header class="header">

            <div class="row">
                <div class="col-md-12">
                    <div class="logo"><a href="index.php">Kriptodgheking</a></div>
                </div>
            </div>

        </header>
        <!-- end header (logo section) -->

        <!-- main menu -->
        <nav class="navbar yamm navbar-default" id="main-navigation">
            <div class="container-fluid">

                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Início</a></li>
                        <li><a href="blog.php">Artigo</a></li>
                        <li><a href="contact.php" >Contactos </a></li>
                        <li><a href="policy.php">Política de privacidade</a></li>
                        <li><a href="terms.php">Termos e condições</a></li>

                    </ul>


                </div><!--/.nav-collapse -->
            </div>
        </nav>
        <!-- end main menu -->

        <div class="content">

            <div class="row">

                <div class="col-md-8 main-content">

                    <!-- Main (left side) -->

                    <section>

                        <div class="row">
                            <div class="col-md-12">

                                <!-- post -->
                                <article class="blog-post">


                                    <div class="post-entry">

                                        <h1>
                                            Obrigado pela sua inscrição!
                                        </h1>





                                    </div>
                                </article>
                                <!-- post end -->

                                <!-- author -->




                            </div><!-- end col-md-12 -->
                        </div><!-- end row -->

                    </section>
                    <!-- END Main (left side) -->

                </div>



            </div><!-- end row -->

        </div><!-- end content -->

        <p id="back-top">
            <a href="#top"><i class="fa fa-angle-up"></i></a>
        </p>


        <!-- end instagram widget in main page -->

    </div> <!-- container div -->

</div> <!-- boxed div -->

<footer class="footer">

    <div class="footer-dark">
        <div class="footer-socials">
            <a href="" class="social"><i class="fa fa-twitter"></i> </a>
            <a href="" class="social"><i class="fa fa-plus"></i> </a>
            <a href="" class="social"><i class="fa fa-facebook-square"></i></a>
            <a href="" class="social dribbble" rel="publisher"><i class="fa fa-dribbble"></i> </a>
            <a href="" class="social google"><i class="fa fa-google-plus-square"></i></a>
        </div>

        <div class="footer-menu">
            <a href="index.php">Início</a>
            <a href="blog.php">Artigo</a>
            <a href="policy.php">Política de privacidade</a>
            <a href="terms.php">Termos e condições</a>
        </div>
    </div>

    <div class="footer-bottom">
        <p>
            Copyright &copy;<script>document.write(new Date().getFullYear());</script>
            All rights reserved
        </p>
    </div>

</footer>
<div class='cookie-banner'>
    <p>
        O site utiliza cookies. Eles permitem reconhecê-lo e de receber alertas com informação sobre a sua experiência do usuário.Continuando a ver o site, eu concordo com o uso de cookies, proprietário do site de acordo com  <a target="_blank" href="https://en.wikipedia.org/wiki/HTTP_cookie">A política de cookies</a>
    </p>
    <button class='close-cookie'>&times;</button>
</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script type="text/javascript" src="js/jquery-latest.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>


<script type="text/javascript" src="js/jquery.scrolline.js"></script>
<script type="text/javascript" src="js/jquery.WCircleMenu-min.js"></script>
<script type="text/javascript" src="js/ThemeScripts.js"></script>

<script>
    window.onload = function () {
        \$('.close-cookie').click(function () {
            \$('.cookie-banner').fadeOut();
        })
    }
</script>
<script>
    let elems = document.querySelectorAll('.server-name');
    elems.forEach((elem) => {
        elem.innerHTML = window.location.hostname
    })
</script>

</body>
</html>